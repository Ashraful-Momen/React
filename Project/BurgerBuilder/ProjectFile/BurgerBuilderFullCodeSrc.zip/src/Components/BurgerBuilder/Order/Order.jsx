import React from "react";
import { fetchOrders } from "../../../redux/actionCreators";
import { connect } from "react-redux";
import SingleOrder from "./SingleOrder/SingleOrder";
import { Spinner } from "reactstrap";

const mapStateToProps = (state) => {
  return {
    orders: state.orders,
    orderLoading: state.orderLoading,
    orderErr: state.orderErr,
    token : state.token,
    userId: state.userId,
  };
};



const mapDispatchToProps = (dispatch) => {
  return {
    fetchOrders: (token,userId) => dispatch(fetchOrders(token,userId)),
  };
};

class Order extends React.Component {
  //after load the full component then call this function .
 //pass the token for fetching user ways .
  componentDidMount() {
    this.props.fetchOrders(this.props.token,this.props.userId);
  }

  //after fetch order from firebase then update the redux state.
  // after update the component then call this function .
 
  componentDidUpdate(prevProps) {
    console.log(this.props.orders);
  }

  render() {

    let orders = null; 
    
    if(this.props.orderErr){
        
        orders = <p> Sorry Faild to Load the Orders </p> 
    
    }
    else{
        if(this.props.orders.length === 0){
            orders = <p>You have no Orders</p>
        }
        else{
        
        orders = this.props.orders.map(order => {
    
           return <SingleOrder order={order} key={order.id} />
            
        })
        }
    
    }
  
   return (
    <div>

  {this.props.orderLoading ? <Spinner /> : orders}
       
        
       
    
    </div>
    );
  }
  
  
 
}

export default connect(mapStateToProps, mapDispatchToProps)(Order);
