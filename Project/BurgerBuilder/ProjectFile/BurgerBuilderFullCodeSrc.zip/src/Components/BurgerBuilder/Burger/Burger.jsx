import React from "react";
import Ingredient from "../Ingredient/Ingredient";

const Burger = (props) => {
  // console.log(props);

  let ingredinetArr = props.ingredients.map((item) => {

    // create the ingredient according to the item.amount , this amount get from BurgerBuilder state.

    //explain Array()  => ...Array(5).keys() => [0,1,2,3,4] //Array(create a array of length 5).keys() => [0,1,2,3,4]

    //if item= 1 ; then amountArr = [0] , if item = 2 ; then amountArr = [0,1] ...

    let amountArr = [...Array(item.amount).keys()];

    //check in the console ;
    // console.log(amountArr); 

    // return the item.type to the <Ingredient /> , from the BurgerBuilder state. 
    return amountArr.map((_,) => {

        return <Ingredient type={item.type} key={Math.random()} />
        
    })
  })
    //why use reducer here : if ingredientArr lenth is 0 , then show "please add some ingredients" in the UI.
    //find out the array lenth that why use this reducer. 

    .reduce((value, increment) => {return value.concat(increment)}, []);

    if(ingredinetArr.length === 0){
        ingredinetArr = <p>please add some ingredients</p>
    }

  return (
    <div className="container  text-center">
      <Ingredient type="bread-top" />
      {ingredinetArr}
      <Ingredient type="bread-bottom" />
    </div>
  );
};

export default Burger;
