import * as actionTypes from "./actionTypes";
import { authLoading } from "./authActionCreators";

const INGREDIENT_PRICES = {
  salad: 10,
  cheese: 20,
  meat: 30,
};

const INITIAL_STATE = {
  ingredients: [
    { type: "salad", amount: 0 },
    { type: "cheese", amount: 0 },
    { type: "meat", amount: 0 },
  ],
  totalPrice: 80,
  purchaseable: false,

  orders: [],
  orderLoading: true,
  orderErr: false,

  //for Auth 
  token: null,
  userId: null,
  authLoading:false,
  authFailedMsg:null,

};

export const reducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case actionTypes.ADD_INGREDIENT: {
      // Create a new array to ensure immutability
      const updatedIngredients = state.ingredients.map((item) => {
        if (item.type === action.payload) {
          return { ...item, amount: item.amount + 1 };
        }
        return item;
      });

      return {
        ...state,
        ingredients: updatedIngredients,
        totalPrice: state.totalPrice + INGREDIENT_PRICES[action.payload],
      };
    }

    case actionTypes.REMOVE_INGREDIENT: {
      // Find the ingredient to check if amount > 0
      const ingredient = state.ingredients.find(
        (item) => item.type === action.payload
      );

      // If ingredient doesn't exist or amount is already 0, return current state
      if (!ingredient || ingredient.amount <= 0) {
        return state;
      }

      // Create a new array with updated amounts
      const updatedIngredients = state.ingredients.map((item) => {
        if (item.type === action.payload) {
          return { ...item, amount: item.amount - 1 };
        }
        return item;
      });

      return {
        ...state,
        ingredients: updatedIngredients,
        totalPrice: state.totalPrice - INGREDIENT_PRICES[action.payload],
      };
    }

    case actionTypes.UPDATE_PURCHASEABLE: {
      // Calculate if we have at least one ingredient
      const sum = state.ingredients.reduce((sum, item) => {
        return sum + item.amount;
      }, 0);

      return {
        ...state,
        purchaseable: sum > 0, // return ture : if sum > 0, we have at least one ingredient
      };
    }

    case actionTypes.RESET_INGREDIENT: {
      return {
        ...state,
        ingredients: [
          { type: "salad", amount: 0 },
          { type: "cheese", amount: 0 },
          { type: "meat", amount: 0 },
        ],
        totalPrice: 80,
        purchaseable: false,
      };
    }

    case actionTypes.LOAD_ORDER_SUCCESS: {
      // console.log(action.payload);
      let orders = [];

      for (let key in action.payload) {
        orders.push({
          ...action.payload[key], //show full item => array[index_number]
          id: key, // UNIQUE order KEY store as an 'id' in array .
        });
      }

      // console.log(orders);

      return {
        ...state,
        orders: orders, // here save all fetching orders from api to react state.
        orderLoading: false,
        orderErr: false,
      };
    }


    case actionTypes.LOAD_ORDER_FAILED: {
      return {
        ...state,
        orderLoading: false,
        orderErr: true,
      };
    }

    //Auth cases
    case actionTypes.AUTH_SUCCESS : 

      return {
        ...state,
        authLoading : false,
        authErr : false,
        token : action.payload.token,
        userId : action.payload.userId
      }

    case actionTypes.AUTH_LOGOUT:
      return {
        ...state,
        token:null,
        userId:null,
      }

      case actionTypes.AUTH_LOADING:
        return {
          ...state,
          authLoading:action.payload,
        }
    
    case actionTypes.AUTH_FAILED: 
    console.log(action.payload); 
    return {
      ...state,
      authFailedMsg:action.payload,
    }

    default:
      return state;
  }
};
