import * as actionTypes from "./actionTypes";
import axios from "axios";

export const addIngredient = (igtype) => {
  return {
    type: actionTypes.ADD_INGREDIENT,
    payload: igtype,
  };
};

export const removeIngredient = (igtype) => {
  return {
    type: actionTypes.REMOVE_INGREDIENT,
    payload: igtype,
  };
};

export const updatePurchaseable = (igtype) => {
  return {
    type: actionTypes.UPDATE_PURCHASEABLE,
    payload: igtype,
  };
};

export const resetIngredient = () => {
  return {
    type: actionTypes.RESET_INGREDIENT,
  };
};

export const loadOrderSuccess = (orders) => {
  return {
    type: actionTypes.LOAD_ORDER_SUCCESS,
    payload: orders, //this is the firebase : url/orders
  };
};

export const loadOrderFailed = () => {
  return {
    type: actionTypes.LOAD_ORDER_FAILED,
  };
};

// async function , dispatch from order.jsx to dispatch from here , that's why use thunk .
export const fetchOrders = (token, userId) => (dispatch) => {
  //fetch the order according to fireBase userId:
  const queryParams = `&orderBy="userId"&equalTo="${userId}"`; // Use template literals

  axios
    .get(
      `https://bbuilder-7276c-default-rtdb.firebaseio.com/orders.json?auth=${token}${queryParams}`
    )
    .then((response) => {
      // Dispatch action with the fetched data
      dispatch(loadOrderSuccess(response.data));
    })
    .catch((err) => {
      console.error("Error fetching orders:", err);
      dispatch(loadOrderFailed());
    });
};
