import axios from "axios";
import * as actionTypes from "./actionTypes";

export const authSuccess = (token, userId) => {
  return {
    type: actionTypes.AUTH_SUCCESS,
    payload: { token: token, userId: userId },
  }
}

export const authLoading = (isLoading) => {

  return {
      type: actionTypes.AUTH_LOADING,
      payload : isLoading ,
  }
}

export const authFaild = errMsg => {
    
  return {
      type : actionTypes.AUTH_FAILED,
      payload : errMsg,
  }


}


export const auth = (email, password,mode) => {

 

  return (dispatch) => {

     dispatch(authLoading(true)); 

    const authData = {
      email: email,
      password: password,
      returnSecureToken: true, // for firebase required
    };

    const api_key = "AIzaSyBv4l6OAV-HD0fGGz9qHk7vkHUiKWrAH0E";
    const signup_url = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=" + api_key;
    const signin_url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" + api_key;
    axios.post(mode === "Sign Up" ? signup_url : signin_url,authData)
      .then((response) => {
        // console.log(response.data);

        dispatch(authLoading(false)); 
        //set the token and userID(localId) to the localStorage: 
        localStorage.setItem('token',response.data.idToken);
        localStorage.setItem('userId',response.data.localId);

        //set the token expire with 1hr cz firebase give us 1hr(In second) but new Date () (In mili - have to convert)
        //set expirationTime = currectTime + 1hr from firebase. 
        const expirationTime = new Date(new Date().getTime() + response.data.expiresIn * 1000)

        localStorage.setItem('expirationTime',expirationTime);

        dispatch(authSuccess(response.data.idToken, response.data.localId)); //pass to authSuccess, then authSuccess will dispatch to reducer
      })
      .catch((err) => {
        dispatch(authFaild(err.message))
        console.log(err.message);
        dispatch(authLoading(false)); 

      });
  };
};



export const logout = () => {
    
  localStorage.removeItem('token');
  localStorage.removeItem('expirationTime');
  localStorage.removeItem('userId');
  
  return {
      type: actionTypes.AUTH_LOGOUT,
      }
  
}




//for auth check : call this function in the root component cz when user run the app firstly check the user has valid token or not. root : <Mian.jsx>

export const authCheck = () => dispatch => {

  //check the token : if token exit and token time not expire then user pass the auth check : 

  const token = localStorage.getItem('token'); 

  if(!token) {
    //Logout
    dispatch(logout()); 


  }
  else{
    // for the date format convertion use => new Date(here_the_code)
    const expirationTime = new Date (localStorage.getItem('expirationTime'))

    //if expiration time <= current time then token expire 
    if(expirationTime <= new Date()){
      //Logout 
      dispatch(logout())
    }
    //this else block : indecate that user has the validate token . 
    else{

      const userId = localStorage.getItem('userId')
      dispatch (authSuccess(token,userId)); 

    }
  }
}