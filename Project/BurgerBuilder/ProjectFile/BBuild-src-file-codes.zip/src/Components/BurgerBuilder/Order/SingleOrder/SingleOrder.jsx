import React from 'react'

const SingleOrder = (props) => {
    // console.log(props);
    let ingredientSummary = props.order.ingredients.map(item => {
        
        return (
            <div className='text-center m-2 border'>

                <span key = {item.type}> {item.amount} X <span> {item.type}</span>  </span> <br/>
            </div>
        )
        
    })
    
    return (
        <div className='border p-2 rounded m-2'>
            <hr />
              {ingredientSummary}
            <p>Order ID : {props.order.id}</p>
            <p>Order Address : {props.order.deliveryAddress}</p>
            <p>Payment Method : {props.order.paymentType}</p>
           
           
          
            <strong>Order Price : {props.order.totalPrice} BDT</strong>
            <hr />
        </div>
    )
}

export default SingleOrder
