import React from "react";

import BreadTop from "/home/ashraful/React/Practise/Builder/Bbuilder-full/src/assets/images/ingreditents/bread_top.png";
import BreadBottom from "/home/ashraful/React/Practise/Builder/Bbuilder-full/src/assets/images/ingreditents/bread_bottom.png";
import Cheese from "/home/ashraful/React/Practise/Builder/Bbuilder-full/src/assets/images/ingreditents/cheese.png";
import Meat from "/home/ashraful/React/Practise/Builder/Bbuilder-full/src/assets/images/ingreditents/meat.png";
import Salad from "/home/ashraful/React/Practise/Builder/Bbuilder-full/src/assets/images/ingreditents/salad.png";

const Ingredient = (props) => {
  // console.log(props.type);
  let ingredient = null;

  switch (props.type) {
    //import the images with the props.types , according to the case add the img :
    case "bread-top":
      ingredient = (
        <div>
          <img
            src={BreadTop}
            alt="Bread"
            style={{ height: "50px", width: "100%" }}
          />
        </div>
      );
      break;
    case "bread-bottom":
      ingredient = (
        <div>
          <img
            src={BreadBottom}
            alt="Bread"
            style={{ height: "50px", width: "100%" }}
          />
        </div>
      );
      break;
    case "cheese":
      ingredient = (
        <div>
          <img
            src={Cheese}
            alt="Cheese"
            style={{ height: "50px", width: "100%" }}
          />
        </div>
      );
      break;
    case "meat":
      ingredient = (
        <div>
          <img
            src={Meat}
            alt="Meat"
            style={{ height: "50px", width: "100%" }}
          />
        </div>
      );
      break;
    case "salad":
      ingredient = (
        <div>
          <img
            src={Salad}
            alt="Salad"
            style={{ height: "50px", width: "100%" }}
          />
        </div>
      );
      break;
    default:
      ingredient = null;
  }

  return <div>{ingredient}</div>;
};

export default Ingredient;
