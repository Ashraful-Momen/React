import React from "react";
import { NavLink } from "react-router-dom";
import { Modal, ModalBody, ModalHeader, ModalFooter, Button } from "reactstrap";
import Burger from "./Burger/Burger";
import Controls from "./Controls/Controls";
import Summary from "./Summary/Summary";

// Redux imports
import { connect } from "react-redux";
import { addIngredient, removeIngredient, updatePurchaseable } from "../../redux/actionCreators";

const mapStateToProps = (state) => {

  return {
    ingredients: state.ingredients,
    totalPrice: state.totalPrice,
    purchaseable: state.purchaseable,
  };
};


//goto actionCreators => then goto reducer => then update the store
const mapDispatchToProps = (dispatch) => {
  return {
    addIngredient: (igtype) => dispatch(addIngredient(igtype)),
    removeIngredient: (igtype) => dispatch(removeIngredient(igtype)),
    updatePurchaseable: () => dispatch(updatePurchaseable()),
  };
};

class BurgerBuilder extends React.Component {
  state = {
    isModalOpen: false,
  };

  addIngredientHandler = (type) => {
    this.props.addIngredient(type);
    this.props.updatePurchaseable();
  };

  removeIngredientHandler = (type) => {
    this.props.removeIngredient(type);
    this.props.updatePurchaseable();
  };

  toggleModal = () => {
    this.setState((prevState) => ({
      isModalOpen: !prevState.isModalOpen,
    }));
  };

  
  render() {
    // Uncomment this to debug Redux state
    // console.log("Current Redux State:", {
    //   ingredients: this.props.ingredients,
    //   totalPrice: this.props.totalPrice,
    //   purchaseable: this.props.purchaseable
    // });
    
    return (
      <div>
        <div className="d-flex flex-md-row flex-column">
          <Burger ingredients={this.props.ingredients} />
          <Controls
            ingredientsAdded={this.addIngredientHandler}
            ingredientsRemoved={this.removeIngredientHandler}
            price={this.props.totalPrice}
            toggleModal={this.toggleModal}
            purchaseable={this.props.purchaseable}
          />
        </div>

        <Modal isOpen={this.state.isModalOpen}>
          <ModalHeader>Order Summary</ModalHeader>
          <ModalBody>
            <h5>Total Price: {this.props.totalPrice.toFixed(0)} BDT</h5>
            <Summary ingredients={this.props.ingredients}/>
          </ModalBody>
          <ModalFooter>
            <Button color="secondary" onClick={this.toggleModal}>
              Cancel
            </Button>
            <NavLink to="/checkout">
            
              <Button color="primary" onClick={this.toggleModal}>
                Continue to Checkout
              </Button>
            </NavLink>
          </ModalFooter>
        </Modal>
      </div>
    );
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(BurgerBuilder);