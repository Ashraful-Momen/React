import React from "react";

const controls = [
  { label: "Meat", type: "meat" },
  { label: "Cheese", type: "cheese" },
  { label: "Salad", type: "salad" },
];

const BuildControl = (props) => {
  return (
    <div className="d-flex justify-content-between">
      <div className="font-weight-bold fs-5">{props.label}</div>
      <div>
        <button className="btn btn-danger m-2 btn-sm" onClick={props.removed}>
          Less
        </button>
        <button className="btn btn-success m-2 btn-sm" onClick={props.added}>
          More
        </button>
      </div>
    </div>
  );
};

const Controls = (props) => {
  // console.log(props);

  return (
    <div
      className="container ms-md-5"
      style={{
        marginTop: "20px",
        marginBottom: "20px",
        textAlign: "center",
      }}>
      <div class="card shadow">
        <div class="card-header">Add Ingredients</div>
        <div class="card-body">
          {controls.map((item) => {
            return (
              <BuildControl
                key={item.label}
                label={item.label}
                type={item.type}
                added={() => props.ingredientsAdded(item.type)}
                removed={() => props.ingredientsRemoved(item.type)}
              />
            );
          })}
        </div>
        <div class="card-footer">Price:{props.price} BDT</div>
        <div class="card-footer">
          <button
            className="btn btn-primary w-100"
            onClick={props.toggleModal}
            disabled={!props.purchaseable}>
            Order Now
          </button>
        </div>
       
      </div>
    </div>
  );
};

export default Controls;
