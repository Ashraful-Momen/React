import React from 'react'
import "./Spinner.css"


const Spinner = () => {
  return (
    <div className='loader d-flex justify-content-center mt-4'>
       <p className='text-center text-dark'> Loading...</p>
    </div>
  )
}

export default Spinner
