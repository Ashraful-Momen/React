import React from "react";
import { Nav, NavItem } from "reactstrap";
import { NavLink } from "react-router-dom";
import { connect } from "react-redux";

const mapStateToProps = (state) => {
  // console.log("redux state", state);
  return {
    isAuthenticated: state.token,
  };
};

const Header = (props) => {
  let links = null;
  if (props.isAuthenticated === null) {
    links = (
      <>
        <NavItem>
          <NavLink className="nav-link" to="/">
            Home
          </NavLink>
        </NavItem>

        <NavItem>
          <NavLink className="nav-link" to="/login">
            Login
          </NavLink>
        </NavItem>
        
       
      </>
    );
  } else {
    links = (
      <>
        <NavItem>
          <NavLink className="nav-link" to="/">
            Home
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink className="nav-link" to="/order">
            Order
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink className="nav-link" to="/checkout">
            Checkout
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink className="nav-link" to="/logout">
            Logout
          </NavLink>
        </NavItem>
        {/* <NavItem>
      <NavLink className="nav-link" to="/login">
        Login
      </NavLink>
    </NavItem> */}
      </>
    );
  }
  return (
    <nav className="navbar navbar-expand-lg bg-body-tertiary shadow sticky-top rounded m-4">
      <div className="container-fluid">
        {/* Brand/Logo */}
        <NavLink className="nav-link navbar-brand" to="/">
          BBuilder
        </NavLink>

        {/* Toggle Button for Mobile */}
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>

        {/* Navbar Links */}
        <div className="collapse navbar-collapse" id="navbarNav">
          <Nav className="navbar-nav ms-auto">
            {" "}
            {/* Use ms-auto to align links to the right */}
            {links}
          </Nav>
        </div>
      </div>
    </nav>
  );
};

export default connect(mapStateToProps, null)(Header);
