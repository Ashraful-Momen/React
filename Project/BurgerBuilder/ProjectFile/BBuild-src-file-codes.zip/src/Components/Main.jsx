import React, { useEffect } from "react";
import { Route, Routes, Navigate } from "react-router-dom";
import { connect } from "react-redux";

import Header from "./Header/Header";
import BurgerBuilder from "./BurgerBuilder/BurgerBuilder";
import Order from "./BurgerBuilder/Order/Order";
import Checkout from "./BurgerBuilder/Order/Checkout/Checkout";
import Auth from "./Auth/Auth";

import { authCheck } from "../redux/authActionCreators";
import Logout from "./Auth/Logout";

export const mapStateToProps = (state) => {
  return {
    isAuthenticated: state.token !== null, // Ensure it's a boolean value
  };
};

// when load app then check the user is authenticated or not .
export const mapDispatchToProps = (dispatch) => {
  return {
    authCheck: () => dispatch(authCheck()), // Return a function that dispatches the action
  };
};

const Main = ({ isAuthenticated, authCheck }) => {
  useEffect(() => {
    authCheck(); // Every time : Call authCheck when the component mounts
  }, [authCheck]);

  return (
    <div>
      <Header />
      <div className="container">
        <Routes>
          {/* Public Route */}
          <Route path="/" element={<BurgerBuilder />} />
          <Route path="/login" element={<Auth />} />
       
          

          {/* Protected Routes */}
          {isAuthenticated ? (
            <>
              <Route path="/" element={<BurgerBuilder />} />
              <Route path="/order" element={<Order />} />
              <Route path="/checkout" element={<Checkout />} />
              <Route path="/logout" element={<Logout />} />
             
            </>
          ) : (
            <Route path="*" element={<Navigate to="/login" replace />} />
          )}
        </Routes>
      </div>
    </div>
  );
};

export default connect(mapStateToProps, mapDispatchToProps)(Main);