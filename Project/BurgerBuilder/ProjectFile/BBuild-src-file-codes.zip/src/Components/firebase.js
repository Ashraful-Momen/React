// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBv4l6OAV-HD0fGGz9qHk7vkHUiKWrAH0E",
  authDomain: "bbuilder-7276c.firebaseapp.com",
  projectId: "bbuilder-7276c",
  storageBucket: "bbuilder-7276c.firebasestorage.app",
  messagingSenderId: "332673287773",
  appId: "1:332673287773:web:277d05fc900f1bb9c92fb4",
  measurementId: "G-H1KYS6V7PL"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);